### Plots

We can use plots.py file to generate the plots that are on the report. It uses a simplified version of the data from the events files of the tensorboard that are stored under data_plot.
 
 ### Config
 
 New config variable called actor_update_freq has been added to the base configs.
 
 

